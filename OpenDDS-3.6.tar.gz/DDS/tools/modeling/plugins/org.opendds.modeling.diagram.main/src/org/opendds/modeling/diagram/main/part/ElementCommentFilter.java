package org.opendds.modeling.diagram.main.part;


/**
 * The GMF Gen Editor Generator Custom Property Tab property expects the
 * filter to be in the part package, even if a qualified name is used.
 * @generated NOT
 */
public class ElementCommentFilter extends org.opendds.modeling.common.gmf.ElementCommentFilter
{
}
