package org.opendds.modeling.diagram.dcpslib.part;

import org.opendds.modeling.diagram.dcpslib.edit.parts.DomainParticipantEditPart;
import org.opendds.modeling.diagram.dcpslib.edit.parts.DomainParticipantQoSPoliciesSharedEditPart;

/**
 * @generated NOT
 */
public class OpenDDSDcpsLibRefQosPolicyActionDomainParticipant extends
OpenDDSDcpsLibRefQosPolicyAction<DomainParticipantQoSPoliciesSharedEditPart> {

	public OpenDDSDcpsLibRefQosPolicyActionDomainParticipant() {
		super(DomainParticipantEditPart.class);
	}

}
