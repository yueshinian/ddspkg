package org.opendds.modeling.diagram.dcpslib.part;

import org.opendds.modeling.diagram.dcpslib.edit.parts.DataReaderEditPart;
import org.opendds.modeling.diagram.dcpslib.edit.parts.DataReaderQoSPoliciesSharedEditPart;

/**
 * @generated NOT
 */
public class OpenDDSDcpsLibRefQosPolicyActionDataReader extends
OpenDDSDcpsLibRefQosPolicyAction<DataReaderQoSPoliciesSharedEditPart> {

	public OpenDDSDcpsLibRefQosPolicyActionDataReader() {
		super(DataReaderEditPart.class);
	}

}
