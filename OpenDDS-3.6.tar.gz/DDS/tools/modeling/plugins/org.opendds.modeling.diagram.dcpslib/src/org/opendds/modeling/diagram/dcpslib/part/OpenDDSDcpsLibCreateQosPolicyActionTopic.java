package org.opendds.modeling.diagram.dcpslib.part;

import org.opendds.modeling.diagram.dcpslib.edit.parts.TopicEditPart;
import org.opendds.modeling.diagram.dcpslib.edit.parts.TopicQoSPoliciesCustomEditPart;

/**
 * @generate NOT
 */
public class OpenDDSDcpsLibCreateQosPolicyActionTopic extends
OpenDDSDcpsLibCreateQosPolicyAction<TopicQoSPoliciesCustomEditPart>
{

	public OpenDDSDcpsLibCreateQosPolicyActionTopic() {
		super(TopicEditPart.class);
	}

}
