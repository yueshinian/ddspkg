package org.opendds.modeling.diagram.dcpslib.part;

import org.opendds.modeling.diagram.dcpslib.edit.parts.DataWriterEditPart;
import org.opendds.modeling.diagram.dcpslib.edit.parts.DataWriterQoSPoliciesCustomEditPart;

/**
 * @generate NOT
 */
public class OpenDDSDcpsLibCreateQosPolicyActionDataWriter extends
OpenDDSDcpsLibCreateQosPolicyAction<DataWriterQoSPoliciesCustomEditPart>
{

	public OpenDDSDcpsLibCreateQosPolicyActionDataWriter() {
		super(DataWriterEditPart.class);
	}

}
