package org.opendds.modeling.diagram.dcpslib.part;

import org.opendds.modeling.diagram.dcpslib.edit.parts.DataReaderEditPart;
import org.opendds.modeling.diagram.dcpslib.edit.parts.DataReaderQoSPoliciesCustomEditPart;

/**
 * @generate NOT
 */
public class OpenDDSDcpsLibCreateQosPolicyActionDataReader extends
OpenDDSDcpsLibCreateQosPolicyAction<DataReaderQoSPoliciesCustomEditPart>
{

	public OpenDDSDcpsLibCreateQosPolicyActionDataReader() {
		super(DataReaderEditPart.class);
	}

}
