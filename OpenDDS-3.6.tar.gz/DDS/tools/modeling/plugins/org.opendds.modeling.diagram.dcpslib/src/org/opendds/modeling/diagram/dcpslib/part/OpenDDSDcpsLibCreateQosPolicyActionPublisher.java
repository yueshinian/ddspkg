package org.opendds.modeling.diagram.dcpslib.part;

import org.opendds.modeling.diagram.dcpslib.edit.parts.PublisherEditPart;
import org.opendds.modeling.diagram.dcpslib.edit.parts.PublisherQoSPoliciesCustomEditPart;

/**
 * @generate NOT
 */
public class OpenDDSDcpsLibCreateQosPolicyActionPublisher extends
OpenDDSDcpsLibCreateQosPolicyAction<PublisherQoSPoliciesCustomEditPart>
{

	public OpenDDSDcpsLibCreateQosPolicyActionPublisher() {
		super(PublisherEditPart.class);
	}

}
