package org.opendds.modeling.diagram.dcpslib.part;

import org.opendds.modeling.diagram.dcpslib.edit.parts.PublisherEditPart;
import org.opendds.modeling.diagram.dcpslib.edit.parts.PublisherQoSPoliciesSharedEditPart;

/**
 * @generated NOT
 */
public class OpenDDSDcpsLibRefQosPolicyActionPublisher extends
OpenDDSDcpsLibRefQosPolicyAction<PublisherQoSPoliciesSharedEditPart> {

	public OpenDDSDcpsLibRefQosPolicyActionPublisher() {
		super(PublisherEditPart.class);
	}

}
