package org.opendds.modeling.diagram.dcpslib.part;

import org.opendds.modeling.diagram.dcpslib.edit.parts.TopicDataTypeEditPart;
import org.opendds.modeling.diagram.dcpslib.edit.parts.TopicEditPart;

/**
 * @generated NOT
 */
public class OpenDDSDcpsLibRefTypeActionTopic extends
OpenDDSDcpsLibRefTypeAction<TopicDataTypeEditPart> {

	public OpenDDSDcpsLibRefTypeActionTopic() {
		super(TopicEditPart.class);
	}

}
