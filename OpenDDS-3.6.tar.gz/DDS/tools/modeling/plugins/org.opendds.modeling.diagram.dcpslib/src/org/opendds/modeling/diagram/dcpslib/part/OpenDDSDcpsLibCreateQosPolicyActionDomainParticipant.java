package org.opendds.modeling.diagram.dcpslib.part;

import org.opendds.modeling.diagram.dcpslib.edit.parts.DomainParticipantEditPart;
import org.opendds.modeling.diagram.dcpslib.edit.parts.DomainParticipantQoSPoliciesCustomEditPart;

/**
 * @generate NOT
 */
public class OpenDDSDcpsLibCreateQosPolicyActionDomainParticipant extends
OpenDDSDcpsLibCreateQosPolicyAction<DomainParticipantQoSPoliciesCustomEditPart>
{

	public OpenDDSDcpsLibCreateQosPolicyActionDomainParticipant() {
		super(DomainParticipantEditPart.class);
	}

}
