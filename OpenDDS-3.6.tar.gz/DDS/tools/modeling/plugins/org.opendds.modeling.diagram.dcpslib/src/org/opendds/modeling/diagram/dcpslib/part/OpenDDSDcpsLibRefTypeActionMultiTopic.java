package org.opendds.modeling.diagram.dcpslib.part;

import org.opendds.modeling.diagram.dcpslib.edit.parts.MultiTopicDataTypeEditPart;
import org.opendds.modeling.diagram.dcpslib.edit.parts.MultiTopicEditPart;
import org.opendds.modeling.diagram.dcpslib.edit.parts.TopicDataTypeEditPart;
import org.opendds.modeling.diagram.dcpslib.edit.parts.TopicEditPart;

/**
 * @generated NOT
 */
public class OpenDDSDcpsLibRefTypeActionMultiTopic extends
OpenDDSDcpsLibRefTypeAction<MultiTopicDataTypeEditPart> {

	public OpenDDSDcpsLibRefTypeActionMultiTopic() {
		super(MultiTopicEditPart.class);
	}

}
