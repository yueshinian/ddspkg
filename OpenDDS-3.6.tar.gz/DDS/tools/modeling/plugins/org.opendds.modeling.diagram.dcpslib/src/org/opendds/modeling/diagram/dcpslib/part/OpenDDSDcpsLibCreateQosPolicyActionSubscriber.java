package org.opendds.modeling.diagram.dcpslib.part;

import org.opendds.modeling.diagram.dcpslib.edit.parts.SubscriberEditPart;
import org.opendds.modeling.diagram.dcpslib.edit.parts.SubscriberQoSPoliciesCustomEditPart;

/**
 * @generate NOT
 */
public class OpenDDSDcpsLibCreateQosPolicyActionSubscriber extends
OpenDDSDcpsLibCreateQosPolicyAction<SubscriberQoSPoliciesCustomEditPart>
{

	public OpenDDSDcpsLibCreateQosPolicyActionSubscriber() {
		super(SubscriberEditPart.class);
	}

}
