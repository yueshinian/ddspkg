package org.opendds.modeling.diagram.dcpslib.part;

import org.opendds.modeling.diagram.dcpslib.edit.parts.DataWriterEditPart;
import org.opendds.modeling.diagram.dcpslib.edit.parts.DataWriterQoSPoliciesSharedEditPart;

/**
 * @generated NOT
 */
public class OpenDDSDcpsLibRefQosPolicyActionDataWriter extends
OpenDDSDcpsLibRefQosPolicyAction<DataWriterQoSPoliciesSharedEditPart> {

	public OpenDDSDcpsLibRefQosPolicyActionDataWriter() {
		super(DataWriterEditPart.class);
	}

}
