package org.opendds.modeling.diagram.dcpslib.part;

import org.opendds.modeling.diagram.dcpslib.edit.parts.TopicEditPart;
import org.opendds.modeling.diagram.dcpslib.edit.parts.TopicQoSPoliciesSharedEditPart;

/**
 * @generated NOT
 */
public class OpenDDSDcpsLibRefQosPolicyActionTopic extends
OpenDDSDcpsLibRefQosPolicyAction<TopicQoSPoliciesSharedEditPart> {

	public OpenDDSDcpsLibRefQosPolicyActionTopic() {
		super(TopicEditPart.class);
	}

}
