package org.opendds.modeling.diagram.policylib.sheet;

/**
 * The GMF Gen Editor Generator Custom Property Tab property expects the
 * property section to be in the part package, even if a qualified name is used.
 * @generated NOT
 */
public class ElementCommentPropertySection extends
		org.opendds.modeling.common.gmf.ElementCommentPropertySection {
}
