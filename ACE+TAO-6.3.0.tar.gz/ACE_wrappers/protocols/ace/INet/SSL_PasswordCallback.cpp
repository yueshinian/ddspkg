// $Id: SSL_PasswordCallback.cpp 91118 2010-07-17 10:29:57Z mcorino $

#include "ace/INet/SSL_PasswordCallback.h"

ACE_BEGIN_VERSIONED_NAMESPACE_DECL

namespace ACE
{
  namespace INet
  {

    SSL_PasswordCallback::SSL_PasswordCallback ()
      {
      }

    SSL_PasswordCallback::~SSL_PasswordCallback ()
      {
      }

  }
}

ACE_END_VERSIONED_NAMESPACE_DECL
