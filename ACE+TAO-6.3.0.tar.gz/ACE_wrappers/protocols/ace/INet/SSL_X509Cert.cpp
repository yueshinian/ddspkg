// $Id: SSL_X509Cert.cpp 91118 2010-07-17 10:29:57Z mcorino $

#include "ace/INet/SSL_X509Cert.h"

#if !defined (__ACE_INLINE__)
#include "ace/INet/SSL_X509Cert.inl"
#endif

ACE_BEGIN_VERSIONED_NAMESPACE_DECL

namespace ACE
{
  namespace INet
  {
  }
}

ACE_END_VERSIONED_NAMESPACE_DECL
